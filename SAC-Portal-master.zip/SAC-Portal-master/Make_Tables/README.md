About mysqlconnect.py

You can use the mydb object of this instantly get the connection part done.

Using the create_insert_stmt function, you can create a insert statement from json data